import java.util.*;
import java.sql.*;

public class CodeSample
{
   
   public static void main(String[] args)
   {
        String searchParm = "";
        String userIn = "";
        String mToMain= "";
        Scanner console = new Scanner(System.in);
        int selection = -1;
       /* try //may be necessary depending on driver version
        {
            Class.forName("com.mysql.jdbc.Driver");
            
        }
        catch(ClassNotFoundException e)
        {
            System.err.println("Could not load MySql JDBC driver!");
            System.exit(-1);
        }*/
        
        try( Connection mysqlCon = DriverManager.getConnection("jdbc:mysql://localhost/"
                                            + "AlphaCollege?user=User&password=abc123");
            Statement stmt = mysqlCon.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY); )
        {
            ResultSet rs = null; //result set is automatically closed when the statment that created it is closed
                                    //or re-executed
            do //-999 corresponds to "q" as I have written this program
            {
                printHeader();
                selection = getSearchOption(console);
                
                switch(selection)
                {
                    case 1: //classes search
                        printHeader();
                        searchParm = getClassSearchVal(console);
                        rs = stmt.executeQuery("Select * from alphacollege.classes");
                        System.out.println("CLASSES");
                        while(rs.next())
                        {
                            String rsClassName = rs.getString("name");
                            if((!searchParm.isEmpty()) && rsClassName.toUpperCase().contains(searchParm.toUpperCase()))
                            {
                                if(rs.getInt("enrolledStudent4") == 0 && rs.getInt("enrolledStudent5") == 0)
                                {
                                    printClassInfo(mysqlCon, rsClassName, rs.getString("major"), rs.getInt("instructor"), 
                                       rs.getInt("enrolledStudent1"), rs.getInt("enrolledStudent2"), rs.getInt("enrolledStudent3"));
                                }
                                else if(rs.getInt("enrolledStudent4") == 0)
                                {
                                    printClassInfo(mysqlCon, rsClassName, rs.getString("major"), rs.getInt("instructor"), 
                                       rs.getInt("enrolledStudent1"), rs.getInt("enrolledStudent2"), rs.getInt("enrolledStudent3"),
                                       rs.getInt("enrolledStudent5"));
                                }
                                else if(rs.getInt("enrolledStudent5") == 0)
                                {
                                    printClassInfo(mysqlCon, rsClassName, rs.getString("major"), rs.getInt("instructor"), 
                                       rs.getInt("enrolledStudent1"), rs.getInt("enrolledStudent2"), rs.getInt("enrolledStudent3"),
                                       rs.getInt("enrolledStudent4"));
                                }
                                else
                                {
                                    printClassInfo(mysqlCon, rsClassName, rs.getString("major"), rs.getInt("instructor"), 
                                       rs.getInt("enrolledStudent1"), rs.getInt("enrolledStudent2"), rs.getInt("enrolledStudent3"),
                                       rs.getInt("enrolledStudent4"), rs.getInt("enrolledStudent5"));
                                }
                            }
                        }
                        
                        break;
                    case 2: //professors search
                        printHeader();
                        rs = stmt.executeQuery("Select * from alphacollege.professors");
                        System.out.println("PROFESSORS");
                        while(rs.next())
                        {
                            System.out.println("\t+ " + rs.getString("firstname") + " " + rs.getString("lastName"));
                        }
                        
                        System.out.println("\nType a professor's name:");
                        searchParm = console.nextLine();
                        rs.absolute(0); //position before first row
                        
                        while(rs.next())
                        {
                            String rsProfName = rs.getString("firstname") + rs.getString("lastName");
                            if((!searchParm.isEmpty()) && rsProfName.toUpperCase().contains(searchParm.toUpperCase()))
                            {
                                printProfClasses(mysqlCon, rs.getInt("facultyId"));
                            }
                        }
                        break;
                    case 3:
                        break;
                    default:
                        break;
                }
                if(selection != -999)
                {
                    System.out.println("Type \"m\" if you want to go to the main page:");
                    mToMain = console.nextLine();
                }
        

            }while(selection != -999 && mToMain.equals("m"));
            if(rs != null)
                rs.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
   
   
   private static void printProfClasses(final Connection dbCon, final int profId)
   {
       final String PROF_CLASS_LOOKUP = "select * from alphacollege.professors where facultyId = ?";
       try(PreparedStatement profLookup = dbCon.prepareStatement(PROF_CLASS_LOOKUP))
       {
           profLookup.setInt(1, profId);
           ResultSet profRs = profLookup.executeQuery();
           profRs.first();
           
           System.out.println("\nPROFESSOR: " + profRs.getString("firstname") + " " + profRs.getString("lastName") + "\n");
           
           System.out.println(profRs.getString("firstname") + " " + profRs.getString("lastName") + " teaches the following "
                   + "classes:");
           System.out.println("\t+ " + profRs.getString("major") + " " + profRs.getInt("courseId1"));
           
           if(profRs.getInt("courseId2") != 0)
           {
              System.out.println("\t+ " + profRs.getString("major") + " " + profRs.getInt("courseId2")); 
           }
           
           if(profRs.getInt("courseId3") != 0)
           {
              System.out.println("\t+ " + profRs.getString("major") + " " + profRs.getInt("courseId3")); 
           }
           profRs.close();
           
       }
       catch(SQLException e)
       {
           e.printStackTrace();
       }
               
   }
 
   /*
   Return value: 1, 2, 3 or -999. 
            -999 indicates the user entered "q" as input.               
   */
   private static int getSearchOption(final Scanner console)
   {
        String userInput;
        boolean successful = false;
        int sel = -1;
       
        do
        {
            System.out.println("Search Options");
            System.out.println("\t1. Search by class name");
            System.out.println("\t2. Search by the name of a professor");
            System.out.println("\t3. Search by the name of a student");
            System.out.println("Please enter your choice:");
            
            userInput = console.nextLine();
            
            if(!userInput.equals("q"))
            {
                try
                {
                    sel = Integer.parseInt(userInput);
                    successful = sel > 0 && sel < 4;
                    if(!successful)
                        throw new NumberFormatException();
                }
                catch(NumberFormatException e)
                {
                    System.out.println("Your choice was not a valid option.\n"
                            + "Please enter the number, as an integer, of the option desired.\n");
                    successful = false;
                }
            }
            else
            {
                successful = true;
                sel = -999;
            }
        }while(!successful);
        
        return sel;
   }
   
   private static void printClassInfo(final Connection dbCon, final String className, 
                                      final String major, 
                                      final int instructorId, final int ... studentIds)
   {
       
       final String PROF_LOOKUP_QRY = "select firstname, lastname from "
                    + "alphacollege.professors where facultyId = ?";
       final String STDNT_LOOKUP_QRY_3 = "select firstname, lastname from "
               + "alphacollege.students where IDNO in (?, ?, ?)";
       final String STDNT_LOOKUP_QRY_4 = "select firstname, lastname from "
               + "alphacollege.students where IDNO in (?, ?, ?, ?)";
       final String STDNT_LOOKUP_QRY_5 = "select firstname, lastname from "
               + "alphacollege.students where IDNO in (?, ?, ?, ?, ?)";
       
       try(PreparedStatement instructorLookup = dbCon.prepareStatement(PROF_LOOKUP_QRY);)
       {
           PreparedStatement studentLookup;
           ResultSet instructorRs;
           ResultSet studentRs;
           if(studentIds.length < 4)
           {
               studentLookup = dbCon.prepareStatement(STDNT_LOOKUP_QRY_3);
               studentLookup.setInt(1, studentIds[0]);
               studentLookup.setInt(2, studentIds[1]);
               studentLookup.setInt(3, studentIds[2]);
               
           }
           else if(studentIds.length > 4)
           {
               studentLookup = dbCon.prepareStatement(STDNT_LOOKUP_QRY_5);
               studentLookup.setInt(1, studentIds[0]);
               studentLookup.setInt(2, studentIds[1]);
               studentLookup.setInt(3, studentIds[2]);
               studentLookup.setInt(4, studentIds[3]);
               studentLookup.setInt(5, studentIds[4]);
           }
           else
           {
               studentLookup = dbCon.prepareStatement(STDNT_LOOKUP_QRY_4);
               studentLookup.setInt(1, studentIds[0]);
               studentLookup.setInt(2, studentIds[1]);
               studentLookup.setInt(3, studentIds[2]);
               studentLookup.setInt(4, studentIds[3]);
           }
          
           instructorLookup.setInt(1, instructorId);
           instructorRs = instructorLookup.executeQuery();
           instructorRs.first();
           
           studentRs = studentLookup.executeQuery();
           
           
           
           
           System.out.println(major + " -> " + className);
           System.out.println("\t+ Professor: " + instructorRs.getString("firstname") + " " + instructorRs.getString("lastName"));
           System.out.println("\t+ Students:");
           while(studentRs.next())
           {
               System.out.println("\t\t+ " + studentRs.getString("firstname") + " " + studentRs.getString("lastname"));
           }
           
           instructorLookup.close();
           instructorRs.close();
           studentLookup.close();
           studentRs.close();
       }
       catch(SQLException e)
       {
           e.printStackTrace();
       }
   }
   
   
   private static void printHeader()
   {
      System.out.println("********************************");
      System.out.println("*** Welcome to Alpha College ***");
      System.out.println("********************************\n");         
      System.out.println("Type 'q' if you want to exit the program\n");
         
   }
   private static String getClassSearchVal(final Scanner console)
   {
       System.out.println("Classes");
       System.out.println("Type the class name:");
       
       return console.nextLine();
       
   }
   
}