-- MySQL dump 10.13  Distrib 8.0.15, for macos10.14 (x86_64)
--
-- Host: localhost    Database: alphacollege
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `classes` (
  `name` varchar(45) DEFAULT NULL,
  `courseNo` int(11) NOT NULL,
  `enrolledStudent1` int(11) NOT NULL,
  `enrolledStudent2` int(11) NOT NULL,
  `enrolledStudent3` int(11) NOT NULL,
  `enrolledStudent4` int(11) DEFAULT NULL,
  `enrolledStudent5` int(11) DEFAULT NULL,
  `instructor` int(11) NOT NULL,
  `major` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`courseNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

LOCK TABLES `classes` WRITE;
/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
INSERT INTO `classes` VALUES ('Finite Math',115,1,6,7,8,4,5,'Math'),('Physics I',123,1,5,9,NULL,NULL,4,'Physics'),('Obj. Oriented Princp.',224,1,6,7,8,NULL,2,'Computer Engineering'),('Physics II',229,1,5,9,NULL,NULL,4,'Physics'),('Essentials of Comp. Prog.',234,1,2,3,4,NULL,3,'Computer Engineering'),('Computer Operation',243,1,2,3,NULL,NULL,2,'Computer Engineering'),('Fluid Mechanics',321,1,5,9,NULL,NULL,4,'Physics'),('Linear Algebra',330,1,2,3,4,5,1,'Math'),('Calculus I',345,4,5,6,7,8,1,'Math'),('Discrete Math',413,2,3,4,NULL,NULL,7,'Math'),('Advanced Prog. in C',423,1,6,7,8,NULL,3,'Computer Engineering');
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `majors`
--

DROP TABLE IF EXISTS `majors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `majors` (
  `name` varchar(25) NOT NULL,
  `courseNo1` int(11) NOT NULL,
  `courseNo2` int(11) NOT NULL,
  `courseNo3` int(11) NOT NULL,
  `courseNo4` int(11) DEFAULT NULL,
  `courseNo5` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `majors`
--

LOCK TABLES `majors` WRITE;
/*!40000 ALTER TABLE `majors` DISABLE KEYS */;
INSERT INTO `majors` VALUES ('Computer Engineering',224,234,423,NULL,NULL),('Math',115,330,345,413,NULL),('Physics',123,321,229,NULL,NULL);
/*!40000 ALTER TABLE `majors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `professors`
--

DROP TABLE IF EXISTS `professors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `professors` (
  `firstname` varchar(15) DEFAULT NULL,
  `lastName` varchar(15) DEFAULT NULL,
  `sex` char(1) DEFAULT NULL,
  `facultyId` int(11) NOT NULL,
  `major` varchar(25) DEFAULT NULL,
  `courseId1` int(11) NOT NULL,
  `courseId2` int(11) DEFAULT NULL,
  `courseId3` int(11) DEFAULT NULL,
  PRIMARY KEY (`facultyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `professors`
--

LOCK TABLES `professors` WRITE;
/*!40000 ALTER TABLE `professors` DISABLE KEYS */;
INSERT INTO `professors` VALUES ('Euler','','M',1,'Math',330,NULL,NULL),('Percy','Jenkins','M',2,'Computer Engineering',224,243,NULL),('Leroy','Jenkins','M',3,'Computer Engineering',234,423,NULL),('Fredrick','VonBonderburg','M',4,'Physics',123,229,321),('Frank','Bender','M',5,'Math',115,NULL,NULL),('Frannie','May','F',6,'Math',345,NULL,NULL),('Tammy','Reefer','F',7,'Math',413,NULL,NULL);
/*!40000 ALTER TABLE `professors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `students` (
  `firstName` varchar(15) DEFAULT NULL,
  `lastName` varchar(15) DEFAULT NULL,
  `major` varchar(25) DEFAULT NULL,
  `sex` char(1) DEFAULT NULL,
  `IDNO` int(11) NOT NULL,
  PRIMARY KEY (`IDNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES ('Jim','Taylor','Physics','M',1),('James','Taylor','Math','M',2),('Jane','Taylor','Math','F',3),('Susan','Green','Math','F',4),('Fredrick','Hennings','Physics','M',5),('Lilly','Alister','Computer Engineering','F',6),('Krista','Jameson','Computer Engineering','F',7),('Brianna','Jameson','Computer Engineering','F',8),('Joey','Polidori','Physics','M',9);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-24 16:39:58
